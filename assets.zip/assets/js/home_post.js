$(document).ready(function() {
    let createPost = function(){
        let newPostForm = $('#new-post-form');

        newPostForm.submit(function(e){
            e.preventDefault();
            $.ajax({
                type:'post',
                url:'/post/create',
                data:newPostForm.serialize(),
                success:function(data){   
                    console.log(data);
                    let newPost = newPostDom(data.data?.post);
                    $('#posts-list-container>ul').prepend(newPost);
                     deletePost($(` .delete-post-button`, newPost));
                    //  new PostComment(data.data.post._id);
                    createComment($(' .new-comment-form', newPost));         
                },error:function(error){
                    console.log(error.responseText);
                }
            })
        });
    }
    let newPostDom = function(post){
        return $(`<div id="post-${post._id }">
                        <small><a class="delete-post-button" href="post/destroy/${post._id}">X</a></small>
                    ${post.user.name}
                    <div class="post-box">
                        ${post.content}
                    </div>
                    <div class="post-comments">
                       
                        <form action="/comment/create" class="new-comment-form" method="post">
                            <input type="text" name="content" placeholder="Type here to add comment">
                            <input type="hidden" name="post" value=" ${post._id}" >
                            <input type="submit" value="Add Comment">
                        </form>
                       
                        <div class="post-comments-list">
                            <ul id="post-comments-${post._id}">
                            
                            </ul>
                        </div>
                    </div>
                </div>`)
    }
    createPost(); // Call the function to bind the event handler

  
        let createComment = function(commentForm){
            console.log('createComment called');
        $(commentForm).submit(function(e){
        e.preventDefault();
        $.ajax({
            type: 'post',
            url: $(commentForm).prop('action'),
            data: commentForm.serialize(),
            dataType:'json',
            success: function(data){
                let newComment = newCommentDom(data.data.comment);
                $(`.post-comments-list>ul`).prepend(newComment);
            },
            error: function(err){
                console.log(err.responseText);
            }
        });
    });
    
    let newCommentDom = function(comment){
        let commentHTML = `
            <li>
                <p>
                    <small><a href="comment/destroy/${comment._id}">X</a></small>
                    ${comment.content}
                    <br>
                    <small>
                        ${comment.user.name}
                    </small>
                </p>
            </li>
        `;
        return commentHTML;
    };
 }

    let deletePost = function(deleteLink){
        $(deleteLink).click(function(e){
            e.preventDefault();

            $.ajax({
                type:'get',
                url:$(deleteLink).prop('href'),
                success:function(data){
                    console.log(data);
                    $(`#post-${data.data.post_id}`).remove();
                },error: function(err){
                    console.log(err.responseText);
                }
            })
        })
    }

});
// {
    //method to submit the form data for new post using AJAX
    // let createPost = function(){
    //     let newPostForm = $('#new-post-form');

    //     newPostForm.submit(function(e){
    //         e.preventDefault();

    //         $.ajax({
    //             type: 'post',
    //             url: '/post/create',
    //             data: newPostForm.serialize(),
    //             success: function(data){
    //                 let newPost = newPostDom(data.data.post);
    //                 $('#posts-list-container>ul').prepend(newPost);
    //                 deletePost($('.delete-post-button', newPost));
    //                 new Noty({
    //                     theme: 'relax',
    //                     text: 'Post published',
    //                     type: 'success',
    //                     layout: 'topRight',
    //                     timeout: 1500
    //                 }).show()
    //                 // window.location.reload();
    //              }, error: function(error){
    //                 console.log(error.responseText);
    //             }
    //         });
    //     });
    // }

    // // method to create a Post in DOM

    // let  newPostDom = function(post){
    //     return $(`<li id="${post._id}">
    //     <p>
    //          <small>
    //          <a class="delete-post-button" href="/posts/destroy/${post._id}">Delete</a>
    //         </small>
    //         ${post.content} 
    //         <br>
    //         <small>
    //             ${post.user.name}  
    //         </small>
    //     </p>
    //     <div class="post-comments">
    //     <form id="post-${ post._id }-comments-form" action="/comment/create" method="POST">
    //     <input type="text" name="content" placeholder="Write a comment..." required>
    //     <input type="hidden" name="post" value="${post._id }">
    //     <input type="submit" value="Comment">
    // </form>
    //         <div class="post-comments-list">
    //             <ul id="post-comments-${post._id}">
    //             </ul>
    //         </div>
    //     </div>
    //  </li>`)
    // }

    // //method to delete a post
    // let deletePost = function(deleteLink){
    //     $(deleteLink).click(function(e){
    //         e.preventDefault();

    //         $.ajax({
    //             type: 'get',
    //             url: $(deleteLink).prop('href'),
    //             success: function(data){
    //                 console.log(data);
    //                 $(`#post-${data.data.post_id}`).remove();
                    

    //                 new Noty({
    //                     theme: 'relax',
    //                     text: 'Post Deleted!',
    //                     type: 'success',
    //                     layout: 'topRight',
    //                     timeout: 1500
    //                 }).show()

    //             },error:function(error){
    //                 console.log(error.responseText);
    //             }
    //         });
    //     });
    // }

    // let convertPostsToAjax = function(post){
    //     $('#posts-list-container>ul>li').each(function(){

    //         let self = $(this);
    //         let deleteButton = $('.delete-post-button', self);
    //         deletePost(deleteButton);

    //         let postId = self.prop('id').split('-')[1];
    //         new PostComments(postId);
    //     });

    // }


    // createPost();
    // convertPostsToAjax();

// }



